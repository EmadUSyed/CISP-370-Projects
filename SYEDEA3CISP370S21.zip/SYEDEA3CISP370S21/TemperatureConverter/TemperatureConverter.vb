﻿Public Class Form1
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles ConvertLabel.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim CelciusTemp As Integer 'Temperature entered in Celcius by user'
        Dim ConvertF As Integer 'Temperature output in Fahrenheit'
        CelciusTemp = CelciusTempTextBox1.Text 'Temperature entered'
        ConvertF = (9 / 5) * CelciusTemp + 32 'Formula to convert Celcius to Fahrenheit'
        ConvertLabel.Text = ConvertF 'Display converted result'
    End Sub

    Private Sub CelciusTempTextBox1_TextChanged(sender As Object, e As EventArgs) Handles CelciusTempTextBox1.TextChanged
        ConvertLabel.Text = ""

    End Sub
End Class
