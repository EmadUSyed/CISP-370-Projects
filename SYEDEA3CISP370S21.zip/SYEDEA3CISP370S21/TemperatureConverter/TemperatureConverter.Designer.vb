﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CelciusTempTextBox1 = New System.Windows.Forms.TextBox()
        Me.ConvertLabel = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(194, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter a Celcius temperature:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(153, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Fahrenheit equivalent:"
        '
        'CelciusTempTextBox1
        '
        Me.CelciusTempTextBox1.Location = New System.Drawing.Point(224, 9)
        Me.CelciusTempTextBox1.Name = "CelciusTempTextBox1"
        Me.CelciusTempTextBox1.Size = New System.Drawing.Size(75, 27)
        Me.CelciusTempTextBox1.TabIndex = 2
        '
        'ConvertLabel
        '
        Me.ConvertLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ConvertLabel.Location = New System.Drawing.Point(224, 44)
        Me.ConvertLabel.Name = "ConvertLabel"
        Me.ConvertLabel.Size = New System.Drawing.Size(75, 28)
        Me.ConvertLabel.TabIndex = 3
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(317, 9)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(94, 29)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Convert"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(423, 87)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ConvertLabel)
        Me.Controls.Add(Me.CelciusTempTextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "TemperatureConverter"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents CelciusTempTextBox1 As TextBox
    Friend WithEvents ConvertLabel As Label
    Friend WithEvents Button1 As Button

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
End Class
