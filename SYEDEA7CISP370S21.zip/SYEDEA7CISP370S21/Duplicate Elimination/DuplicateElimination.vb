﻿'Emad Syed
'W1768101
'CISP 370 Spring 2021
'Creating an Array of 20 inputted values by user and filtering out duplicates
'Assignment 7
'*Help was taken by professor*

Public Class DuplicateEliminator
    Dim numbox(19) As Integer 'initializing an array with a length of 20
    Dim EntnumCnt As Integer = 0 'initializing the Count for the entered number lisst
    Dim UniNumCnt As Integer = 0 'initializing the count for unique number list
    Dim T As Boolean = False 'initializing the Boolean for the unique number check
    Private Sub OKButton_Click(sender As Object, e As EventArgs) Handles OKButton.Click
        Dim num As Integer
        num = Val(NumEnter.Text) 'User Inputted value
        If num < 10 Or num > 100 Then 'Checking to see if the value is between 10-100
            MessageBox.Show("Please enter a number between 10 - 100", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            T = True
            NumEnt.Items.Add(num) 'Adding values to our "Entered Number" list
            For i = 0 To EntnumCnt
                If (num = numbox(i)) Then T = False 'Checking for Uniqueness
            Next
            numbox(EntnumCnt) = num
            EntnumCnt += 1 'Increamenting the count for "entered number list"
            Label2.Text = "Numbers Entered " & EntnumCnt 'incrementing the value on display of "Numbers Entered" list
            If T = True Then
                UniNum.Items.Add(num) 'Adding number to "unique number" list
                UniNumCnt += 1 'incrementing the unique number count
            End If
            Label3.Text = "Unique Numbers Entered " & UniNumCnt 'incrementing and displaying count on "Unique Numbers"

            NumEnter.Clear()

        End If
        If EntnumCnt > 20 Then 'Limit check
            MessageBox.Show("20 numbers successfully inputted", "Task Completed", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
End Class
