﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DuplicateEliminator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumEnter = New System.Windows.Forms.TextBox()
        Me.OKButton = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.NumEnt = New System.Windows.Forms.ListBox()
        Me.UniNum = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter Number:"
        '
        'NumEnter
        '
        Me.NumEnter.Location = New System.Drawing.Point(122, 28)
        Me.NumEnter.Name = "NumEnter"
        Me.NumEnter.Size = New System.Drawing.Size(125, 27)
        Me.NumEnter.TabIndex = 1
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(273, 28)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(94, 29)
        Me.OKButton.TabIndex = 2
        Me.OKButton.Text = "OK"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(124, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Numbers Entered"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(178, 69)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(175, 20)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Unique Numbers Entered"
        '
        'NumEnt
        '
        Me.NumEnt.FormattingEnabled = True
        Me.NumEnt.ItemHeight = 20
        Me.NumEnt.Location = New System.Drawing.Point(12, 92)
        Me.NumEnt.Name = "NumEnt"
        Me.NumEnt.Size = New System.Drawing.Size(150, 224)
        Me.NumEnt.TabIndex = 7
        '
        'UniNum
        '
        Me.UniNum.FormattingEnabled = True
        Me.UniNum.ItemHeight = 20
        Me.UniNum.Location = New System.Drawing.Point(178, 92)
        Me.UniNum.Name = "UniNum"
        Me.UniNum.Size = New System.Drawing.Size(189, 224)
        Me.UniNum.TabIndex = 8
        '
        'DuplicateEliminator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(379, 329)
        Me.Controls.Add(Me.UniNum)
        Me.Controls.Add(Me.NumEnt)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.NumEnter)
        Me.Controls.Add(Me.Label1)
        Me.Name = "DuplicateEliminator"
        Me.Text = "Duplicate Elimination"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents NumEnter As TextBox
    Friend WithEvents OKButton As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents NumEnt As ListBox
    Friend WithEvents UniNum As ListBox
End Class
