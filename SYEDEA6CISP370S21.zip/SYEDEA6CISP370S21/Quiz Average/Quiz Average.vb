﻿'Emad Syed
'W1768101
'CISP 370 Spring 2021
'Calculating average of indeterminate amount of quizzes score entered by user
'Week 6


Public Class Form1
    Dim score As Integer = 0 'To keep track of score entered by user    
    Dim count As Integer = 0 'To Keep track of how many times entered by user
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        score = Convert.ToInt32(ScoreBox.Text) 'Takes in vaue by user and coverts 32-bit integer

        count += 1 'Incrementing

        AvgBox.Text = String.Format("{0:F2}", Avg(score, count)) 'Outputting the result in 2 Decimal points

        CountBox.Text = count.ToString() 'Outputting number of tries

    End Sub

    Shared Function Avg(scr As Integer, cnt As Integer) As Double 'the Average Calculator:  help taken by Professor and unnamed student
        Return scr / cnt
    End Function
End Class
