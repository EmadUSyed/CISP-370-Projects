﻿'Emad Syed 
'W1768101
'CISP 370 Spring 2021
'The Factorial app calculates the factorial of an integer input by the user.

'Chapter 5: Problem Solving & Control Statements: Part 2

Public Class Factorial

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num, ans As Integer
        num = Val(TextBox1.Text) 'value counter by user
        ans = 1 'all factorials begin with 1
        If num < 0 Then
            ResultLabel3.Text = "!! Undefined !!" 'in case number input is in negative
        Else
            While (num > 0) 'Beginning of the the factorial computation
                ans *= num
                num -= 1
            End While
            ResultLabel3.Text = ans 'outputting the final result
        End If
    End Sub
End Class
